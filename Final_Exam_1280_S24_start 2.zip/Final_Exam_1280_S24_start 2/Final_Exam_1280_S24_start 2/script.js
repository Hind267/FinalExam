// get the date from the input field

var thisDate = new Date("August 14, 2024 00:00:00").getTime();


function getDate() {

  var now = new Date().getTime();

  var distance = thisDate - now;
 


  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
  var miseconds = Math.floor((distance % (1000 * 60)) / 10);


  document.getElementById("demo").innerHTML = days + "days " + hours + "hrs "
  + minutes + "mins" + seconds + "secs " + miseconds +"dicsecs" ;

  if (distance < 0) {
    clearInterval(getDate);
    document.getElementById("demo").innerHTML = "Times Up";
        }
    } 
getDate()
setInterval(getDate,1000)



function start() {
    const thisDay = new Date();
    const yy = thisDay.getFullYear();
    const mm = thisDay.getMonth() +1; 
    const dd = thisDay.getDate(); 
    const result = `${yy}/${mm}/${dd}`;
    document.getElementById("birthday").innerText = yy;
    document.getElementById("birthday").innerText = mm;
    document.getElementById("birthday").innerText = dd;
   

     console.log(result)

}

start();
setInterval(start, 1000);

